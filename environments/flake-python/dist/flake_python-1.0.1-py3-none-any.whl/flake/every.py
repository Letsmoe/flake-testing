from .shared import comments

def every(description: str):
	comments["__main"] = description