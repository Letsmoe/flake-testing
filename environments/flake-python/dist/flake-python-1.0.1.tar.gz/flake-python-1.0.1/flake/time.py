import time

def getTime():
	return time.time_ns() // 1_000_000