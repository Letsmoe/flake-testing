from .shared import comments

def group(group: str, description: str):
	comments[group] = description